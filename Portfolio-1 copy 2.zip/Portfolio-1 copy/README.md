# Portfolio Website

A modern, responsive portfolio website built with HTML, CSS, and JavaScript that demonstrates web development skills and showcases projects.

## Features

### 🎯 Laboratory Activity 1: HTML Structure Enhancement
- **Navigation Bar**: Horizontal navigation with Home, About, Projects, and Contact links
- **Hero Section**: Full-height hero section with call-to-action button
- **About Section**: About Me paragraph with profile image
- **Semantic HTML**: Proper use of HTML5 semantic elements

### 🎨 Laboratory Activity 2: CSS Styling and Customization
- **Modern Design**: Clean, professional design with smooth animations
- **Google Fonts**: Poppins font family for headings and body text
- **Hover Effects**: Interactive hover animations for buttons and links
- **Responsive Layout**: CSS Grid and Flexbox for modern layouts
- **Smooth Transitions**: CSS transitions and transforms for enhanced UX

### 📱 Laboratory Activity 3: Responsive Design
- **Mobile-First**: Responsive design that works on all screen sizes
- **Media Queries**: CSS media queries for mobile optimization
- **Mobile Navigation**: Collapsible hamburger menu for mobile devices
- **Responsive Images**: Images that scale appropriately with screen size

### ⚡ Laboratory Activity 4: Interactivity with JavaScript
- **Button Alerts**: JavaScript alert when "Hire Me" button is clicked
- **Image Slider**: Interactive image slider with navigation buttons and dots
- **Back to Top**: Button that appears after scrolling and smoothly returns to top
- **Mobile Menu**: JavaScript-powered mobile navigation toggle
- **Smooth Scrolling**: Smooth scrolling between sections

### 🚀 Laboratory Activity 5: Portfolio Expansion
- **Project Cards**: Three project cards with images and descriptions
- **Contact Form**: Functional contact form with validation
- **Form Validation**: JavaScript validation for empty fields and email format
- **Interactive Elements**: Hover effects and animations throughout

## Technologies Used

- **HTML5**: Semantic markup and structure
- **CSS3**: Modern styling with Grid, Flexbox, and animations
- **JavaScript (ES6+)**: Interactive functionality and form validation
- **Google Fonts**: Poppins font family
- **Responsive Design**: Mobile-first approach

## File Structure

```
Portfolio/
├── index.html          # Main HTML file
├── styles.css          # CSS styles and responsive design
├── script.js           # JavaScript functionality
└── README.md           # Project documentation
```

## How to Use

1. **Open the Website**: Simply open `index.html` in any modern web browser
2. **Navigate**: Use the navigation menu to jump between sections
3. **View Projects**: Browse through the project cards and image slider
4. **Contact**: Fill out the contact form (validation included)
5. **Mobile**: Test responsive design by resizing your browser window

## Features in Detail

### Navigation
- Fixed navigation bar with smooth hover effects
- Mobile-responsive hamburger menu
- Smooth scrolling to sections

### Hero Section
- Full-height hero with gradient background
- Animated text and button
- Responsive typography

### About Section
- Two-column layout (responsive on mobile)
- Profile image with hover effects
- Professional description

### Image Slider
- Three-image carousel with navigation
- Auto-advancing slides every 5 seconds
- Interactive dots and navigation buttons

### Projects Section
- Three project cards with hover effects
- Responsive grid layout
- Project images and descriptions

### Contact Form
- Name, email, and message fields
- JavaScript validation
- Success/error messaging
- Form reset after submission

### Back to Top Button
- Appears after scrolling down
- Smooth scroll to top functionality
- Fixed positioning

## Browser Compatibility

- Chrome (recommended)
- Firefox
- Safari
- Edge
- Mobile browsers (iOS Safari, Chrome Mobile)

## Customization

### Colors
The website uses a modern color palette:
- Primary: #4A90E2 (Blue)
- Secondary: #FF6B6B (Coral)
- Accent: #4ECDC4 (Teal)
- Text: #333 (Dark Gray)

### Fonts
- Primary: Poppins (Google Fonts)
- Weights: 300, 400, 500, 600, 700

### Images
- Replace placeholder images with your own
- Update profile picture in the About section
- Add your project images to the Projects section
- Customize the image slider with your work

## Performance Features

- Optimized CSS with efficient selectors
- Smooth animations using CSS transforms
- Lazy loading for images
- Minimal JavaScript for fast loading
- Responsive images for different screen sizes

## Future Enhancements

- Add more project categories
- Implement a blog section
- Add dark/light theme toggle
- Integrate with a backend for form submission
- Add portfolio filtering and search
- Implement smooth page transitions

## License

This project is open source and available under the MIT License.

---

**Created for**: Web Development Laboratory Activities  
**Technologies**: HTML5, CSS3, JavaScript  
**Design**: Modern, Responsive, Professional
