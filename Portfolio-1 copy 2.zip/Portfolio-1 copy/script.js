// Mobile Navigation Toggle
const hamburger = document.querySelector('.hamburger');
const navMenu = document.querySelector('.nav-menu');

hamburger.addEventListener('click', () => {
    hamburger.classList.toggle('active');
    navMenu.classList.toggle('active');
});

// Close mobile menu when clicking on a link
document.querySelectorAll('.nav-menu a').forEach(link => {
    link.addEventListener('click', () => {
        hamburger.classList.remove('active');
        navMenu.classList.remove('active');
    });
});

// Smooth scrolling for nav links
document.querySelectorAll('a[href^="#"]').forEach(anchor => {
    anchor.addEventListener('click', function(e){
        e.preventDefault();
        const target = document.querySelector(this.getAttribute('href'));
        if(target){
            target.scrollIntoView({behavior:'smooth', block:'start'});
        }
    });
});

// Image Slider Functionality
let currentSlideIndex = 0;
const slides = document.querySelectorAll('.slide');
const dots = document.querySelectorAll('.dot');

function showSlide(index){
    slides.forEach(s => s.classList.remove('active'));
    dots.forEach(d => d.classList.remove('active'));
    if(index >= slides.length) currentSlideIndex = 0;
    if(index < 0) currentSlideIndex = slides.length -1;
    slides[currentSlideIndex].classList.add('active');
    dots[currentSlideIndex].classList.add('active');
}

function changeSlide(direction){
    currentSlideIndex += direction;
    showSlide(currentSlideIndex);
}

function currentSlide(n){
    currentSlideIndex = n-1;
    showSlide(currentSlideIndex);
}

// Auto slide every 5 seconds
setInterval(()=>{ changeSlide(1); },5000);

// Back to Top Button
const backToTopBtn = document.getElementById('back-to-top');
window.addEventListener('scroll', ()=>{
    if(window.pageYOffset > 300){
        backToTopBtn.style.display = 'block';
    } else {
        backToTopBtn.style.display = 'none';
    }
});
function scrollToTop(){
    window.scrollTo({top:0, behavior:'smooth'});
}

// Hire Me Button Alert
function showAlert(){
    alert('Thank you for your interest! Please contact me through the form below.');
}

// Form Validation
function validateForm(event){
    event.preventDefault();
    const name = document.getElementById('name').value.trim();
    const email = document.getElementById('email').value.trim();
    const message = document.getElementById('message').value.trim();
    let isValid = true;
    let errorMsg = '';

    if(name===''){ errorMsg+='Name is required.\n'; isValid=false; }
    if(email===''){ errorMsg+='Email is required.\n'; isValid=false; }
    else if(!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)){ errorMsg+='Enter a valid email.\n'; isValid=false; }
    if(message===''){ errorMsg+='Message is required.\n'; isValid=false; }

    if(isValid){
        alert('Thank you! I will get back to you soon.');
        document.getElementById('name').value='';
        document.getElementById('email').value='';
        document.getElementById('message').value='';
    } else {
        alert('Please fix the errors:\n'+errorMsg);
    }
}

// Typing Effect on Hero Title
function typeWriter(el, text, speed=100){
    let i=0;
    el.innerHTML='';
    function type(){
        if(i<text.length){
            el.innerHTML += text.charAt(i);
            i++;
            setTimeout(type,speed);
        }
    }
    type();
}

window.addEventListener('load', ()=>{
    const heroTitle = document.querySelector('.hero-title');
    if(heroTitle){
        typeWriter(heroTitle, heroTitle.textContent, 100);
    }
});

// Scroll Reveal Animations
const observer = new IntersectionObserver((entries)=>{
    entries.forEach(entry=>{
        if(entry.isIntersecting){
            entry.target.style.opacity='1';
            entry.target.style.transform='translateY(0)';
        }
    });
},{threshold:0.1, rootMargin:'0px 0px -50px 0px'});

document.querySelectorAll('section').forEach(sec=>{
    sec.style.opacity='0';
    sec.style.transform='translateY(30px)';
    sec.style.transition='opacity 0.6s ease, transform 0.6s ease';
    observer.observe(sec);
});

// Scale animation for project cards
document.querySelectorAll('.project-card').forEach(card=>{
    card.addEventListener('mouseenter', ()=>{ card.style.transform='scale(1.02)'; });
    card.addEventListener('mouseleave', ()=>{ card.style.transform='scale(1)'; });
});

// Button click effect
document.querySelectorAll('button').forEach(btn=>{
    btn.addEventListener('click', ()=>{
        btn.style.transform='scale(0.95)';
        setTimeout(()=>{ btn.style.transform='scale(1)'; },150);
    });
});
// Floating animation for Hire Me button
const hireBtn = document.querySelector('.hire-me-btn');
let floatDirection = 1;
setInterval(() => {
    const currentTop = parseFloat(getComputedStyle(hireBtn).top) || 0;
    hireBtn.style.top = `${currentTop + 0.5 * floatDirection}px`;
    if (currentTop > 10 || currentTop < -10) floatDirection *= -1;
}, 100);
